# WeatherApiApp

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.6.3.

## Run

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.

Run `node server.js` 

open `http://localhost:3000/` in browser